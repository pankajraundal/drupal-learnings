<?php


namespace Drupal\batchimp\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form with examples on how to use cache.
 */
class TriggerImport extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'download_and_import_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['description'] = [
      '#type' => 'markup',
      '#markup' => $this->t('Click on import in batches button to import ready jobs.'),
    ];

    // Field which collect btach size in which records needs to delete.
    $form['batch_size'] = [
      '#type' => 'number',
      '#title' => 'Delet users in batch size',
      '#description' => $this->t('Add number for batch size which needs to process at a time.'),
      '#maxlength' => 3,
      '#min' => 1,
    ];


    
    // Submit button.
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Import jobs in batches',
    ];
    return $form;
  }

  

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  
    // Validation for batch size.
    $batchSize = $form_state->getValue('batch_size');
    if (empty($batchSize)) {
      $form_state->setErrorByName('batch_size', $this->t('Please enter batch size in which records needs to delete.'));
    }
    // Batch size should only contains numbers.
    if (!empty($batchSize)) {
      if (!is_numeric($batchSize)) {
        $form_state->setErrorByName('batch_size', $this->t('Please enter only integer value for batch size.'));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Process job, update status, aknowledge, download and import.
    \Drupal::service('batchimp.process_job')->aknowledgeJobs();
  }
}
