<?php

namespace Drupal\batchimp\Services;

/**
 * Service to process job.
 *
 * Acknowledge, update, delete jobs.
 *
 * @category Class
 * @package Drupal\batchapi\Services
 * @author Lionbridge team
 */
class ProcessJob {
  /**
   * Function to download Job, auto accept and approve.
   *
   * @param array $job_info
   *   Jobs which nees to download, autoaccept and approve.
   */

  public function aknowledgeJobs () {
    $capi_jobs_to_aknowledge['pankaj']['requestIds'] = [
      "This is test 1",
      "This is test 2",
      "This is test 3",
      "This is test 4",
      "This is test 5",
      "This is test 6",
      "This is test 7",
    ];
    $capi_jobs_to_aknowledge['pankaj']['type'] = 2;
    $capi_jobs_to_aknowledge['pankaj']['providerId'] = "Pankaj 123";
    $capi_jobs_to_aknowledge['pankaj']['drupalJob'] = "Pankaj job to finsh";
    $capi_jobs_to_aknowledge['pankaj']['prid'] = "1234";

    $capi_jobs_to_aknowledge['ayush']['requestIds'] = [
      "This is test 8",
      "This is test 9",
      "This is test 10",
      "This is test 11",
      "This is test 12",
      "This is test 13",
      "This is test 14",
    ];
    $capi_jobs_to_aknowledge['ayush']['type'] = 2;
    $capi_jobs_to_aknowledge['ayush']['providerId'] = "Pankaj 123";
    $capi_jobs_to_aknowledge['ayush']['drupalJob'] = "Pankaj job to finsh 1";
    $capi_jobs_to_aknowledge['ayush']['prid'] = "5678";

    $capi_jobs_to_aknowledge['aadisha']['requestIds'] = [
      "This is test 15",
      "This is test 16",
      "This is test 17",
      "This is test 18",
      "This is test 19",
      "This is test 20",
      "This is test 21",
    ];
    $capi_jobs_to_aknowledge['aadisha']['type'] = 2;
    $capi_jobs_to_aknowledge['aadisha']['providerId'] = "Pankaj 123";
    $capi_jobs_to_aknowledge['aadisha']['drupalJob'] = "Pankaj job to finsh 2";
    $capi_jobs_to_aknowledge['aadisha']['prid'] = "9876";

    foreach ($capi_jobs_to_aknowledge as $value) {
      $this->downloadJob($value);
    }
  }
  public function downloadJob(array $job_info) {
    $request_ids = $job_info['requestIds'];
    try {
     
      //$this->messenger()->addWarning($this->getStringTranslation()->formatPlural($num_of_items, '1 conflicting item has been dropped for job @label.', '@count conflicting items have been dropped for job @label.', ['@label' => $job->label()]));
      // Gather data for batch processing.
      $batch = [
        'title' => t('Started download and import items for job @label.', ['@label' => 'Test 1']),
        'operations' => [],
        'finished' => [ProcessJob::class, 'batchSubmitFinished'],
      ];

      foreach ($request_ids as $request_id) {
        $batch['operations'][] = [
          [ProcessJob::class, 'batchSubmit'],
          [$request_id, $job_info],
        ];
      }
      // Initiate batch process.
      batch_set($batch);
    }
    catch (Exception $exception) {
      $respbody = $exception->getMessage();
      if ($exception instanceof ApiException) {
        $respbody = $exception->getResponseBody();
      }
      $respbody = 'An error occured while fetching and importing files: ' . $respbody;
      if (strlen($respbody) > 200) {
        $respbody = substr($respbody, 0, 200);
      }
      \Drupal::messenger()->addMessage($respbody, 'error');
    }
  }

  /**
   * Batch dispatch callback for submitting a job.
   *
   * @param int $idarray
   *   The job items which are processed.
   * @param array $job_info
   *   Job detail whose items ha been procesed.
   */
  public static function batchSubmit($idarray, $job_info, &$context) {
    \Drupal::service('batchimp.process_job')->processRequestId($idarray, $job_info, $context);
  }

  /**
   * Function to process request in a batch.
   * 
   * @param string $request_id
   *   Request id to process.
   * 
   * @param array $job_info
   *   Job related information.
   * 
   * @param mixed string $context
   *   Context.
   */
  public function processRequestId($request_id, $job_info, &$context) {
    
    $job = $job_info['drupalJob'];
    $prId = $job_info['prid'];
    $job_from = $job_info['type'];
    $providerId = $job_info['providerId']; 
    if (empty($context['sandbox'])) {
      $context['results'][$prId] = [];
      $context['results']['job_items'] = 0;
    }
    $context['results']['job_items']++;
    $context['results'][$prId]['job_from'] = $job_from;
    $context['results'][$prId]['provider_id'] = $providerId;
    $context['results'][$prId]['job'] = $job;
    $context['results'][$prId]['requestIds'] = $job_info['requestIds'];
  }
  
  /**
   * Batch dispatch submission finished callback.
   */
  public static function batchSubmitFinished($success, $results, $operations) {
    return \Drupal::service('batchimp.process_job')->doBatchSubmitFinished($success, $results, $operations);
  }

  /**
   * Batch submission finished callback.
   */
  public function doBatchSubmitFinished($success, $results, $operations) {
    // The 'success' parameter means no fatal PHP errors were detected. All
    // other error management should be handled using 'results'.
    if ($success) {
      if (!empty($results)) {
        $prIds = array_keys($results);
        $i = 0;
        foreach ($prIds as $prId) {
         
          
          if(!isset($results[$prId]["provider_id"])) {
            continue;
          }
          kint($i);
          $i++;
          foreach ($results[$prId]["requestIds"] as $id) {
            \Drupal::messenger()->addWarning(t('@id processed.', 
            [
              '@id' => $id,
            ]
            ));
          }
          \Drupal::messenger()->addWarning(t('@i details Job From: @jobfrom, Provider Id: @provider_id,  Job: @job, processed.', 
          [
            '@i' => $i,
            '@jobfrom' => $results[$prId]["job_from"],
            '@provider_id' => $results[$prId]["provider_id"],
            '@job' => $results[$prId]["job"],
          ]
          ));
        }
      }
    }
    else {
      \Drupal::messenger()->addWarning(t('None of the selected sources can be added to continuous jobs.'));
    }

  }
  
}
